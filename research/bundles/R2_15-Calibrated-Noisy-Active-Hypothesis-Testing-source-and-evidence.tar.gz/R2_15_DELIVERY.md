# Nolane R2.15 — Calibrated Active Hypothesis Testing under Noisy / Partial Evidence + Distribution Shift

Date: 2026-08-15  
Status: **PHASE-A INTERNAL GATE ACCEPTED / EXTERNAL GENERALITY UNPROVEN**

## Capability added

R2.15 adds **0 neural parameters**, keeping the coding-track neural total at **79,450,489**. It extends R2.14 from an exact finite oracle to a deliberately imperfect evidence setting:

`raw noisy / missing evidence -> immutable ledger -> probe-group consensus -> soft hypothesis scores -> active discriminator -> leader falsification probe -> cross-domain boundary sentinel -> assumption audit -> resolve or abstain`

Repeated responses at one probe remain individually preserved for audit but count as one correlated hypothesis-evidence unit. A strict-majority consensus that no surviving in-class hypothesis can explain is treated as direct out-of-class evidence and forces abstention. The final two confirmation groups deliberately test both the current leader against retained alternatives and the edge of the declared probe domain.

## Frozen protocol

`research/R2_15_PRE_HELDOUT_LOCK.json` was written before heldout.

- lock SHA-256: `24eb493e36f87de189e6a96582a3197964903c723273b86adff71550fb9f3f27`
- DEV seeds: 23001..23005
- heldout seed: 33001
- heldout tasks: 96 (24 per family × 4 families)
- evidence regimes: exact, iid noisy+missing, burst-correlated noise, persistent localized corruption, shifted/out-of-class behavior
- policies: robust-active, robust-passive, robust-random, majority hard-filter, naive hard-filter
- raw-call ceiling: 30
- group size: 5 raw calls / probe
- confirmation groups: 2
- new neural parameters: 0

## Frozen heldout result

Robust-active:

- exact: **100.000% accuracy**, 100.000% coverage, 0 false accepts
- iid noisy/missing: **73.958% accuracy**, 73.958% coverage, 0 false accepts
- burst-correlated noise: **78.125% accuracy**, 78.125% coverage, 0 false accepts
- localized persistent corruption: **100.000% accuracy**, 100.000% coverage, 0 false accepts
- shifted/out-of-class: **0.000% coverage**, 0 false accepts
- minimum class-order invariance: **100.000%**
- max raw calls: **30**
- total robust-active false resolved accepts across all 480 regime-task evaluations: **0**

Safety contrast, same heldout:

- majority hard-filter shifted/OOC: 86.458% coverage with **83 false accepts**
- majority hard-filter localized corruption: 0.000% accuracy with **77 false accepts**
- robust-random localized corruption: 89.583% accuracy, 0 false accepts
- robust-passive localized corruption: 71.875% accuracy, 0 false accepts

The candidate is intentionally selective: under iid/burst noise it may abstain where hard filters keep guessing. That lower coverage is counted honestly rather than converted into artificial accuracy.

Heldout raw SHA-256: `03d9cd352b8aa81fc9443060f7996c2f151e141b69ff1a333344fb3f2f2ebfc8`  
Result SHA-256: `1cc288016667561284cf2165e96078270962d67068e1c03d50b95c9fd4bc3997`

## AGI engineering-readiness

**20.0/100 -> 20.6/100 (+0.6).**

The credit is deliberately small. R2.15 demonstrates internal finite-domain calibration under several synthetic feedback failures and a deliberately out-of-class shift. It still assumes a pre-enumerated hypothesis class, a known bounded probe domain, and a callable oracle. It does not show open-world hypothesis creation, natural-language/world-model learning, multimodal grounding, unrestricted coding, or AGI.

## Verification boundary

Focused R2.12–R2.15 plus R2.3 regression and compileall are recorded in `research/R2_15_REGRESSION_AUDIT.json`. The broad root suite still contains pre-existing lineage debt in historical R2.1 compatibility and the rejected R2.5 ARC track; those unrelated failures are not silently folded into this milestone.

The GitHub Actions reproduction workflow is `.github/workflows/r215-noisy-active-hypothesis-testing.yml`. If account billing/spending limits prevent runner allocation, that is recorded as infrastructure-blocked-before-execution rather than represented as a CI pass.

## Next bottleneck

R2.15 can reject evidence that lies outside its closed hypothesis class, but it cannot **invent a new hypothesis** when the true behavior is absent. The next research axis is open-world hypothesis expansion / revision: detect class misspecification, propose a small number of new executable hypotheses from residual evidence, test them actively, and promote only after independent falsification.

## Claim boundary

R2.15 is internal synthetic finite-domain evidence. External coding, unrestricted software engineering, frontier-model parity and AGI claims remain disabled.
